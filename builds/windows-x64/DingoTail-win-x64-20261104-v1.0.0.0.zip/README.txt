DingoTail — self-contained Windows x64 release
Built 2026-11-04. Extract the entire ZIP and run DingoTail.exe.
No separate .NET installation is required. Keep all files together.
Includes .NET and Windows Desktop 8.0.27 runtimes.

Search: use the magnifier in a log pane, or Ctrl+F for the active pane.
Find/include and Exclude match case-insensitively; enable Regular expression
for regex matching. Invalid expressions keep the last valid filter.
Filters are per source and last only for this app session. Export writes all
matching retained lines; Copy copies the selected visible row. Resume follow
moves to the newest matching rows.

SFTP: Browse with sudo (read-only) is off by default. It requires existing
passwordless sudo permission for a supported external OpenSSH sftp-server -R.
This option is independent of sudo for reading log commands. No server policy
or permissions are changed by the app.

Delete server: right-click a server, or use its SSH toolbar submenu. Confirming
closes its sources and removes the saved profile. Approved endpoint trust is
retained; passwords and passphrases are not saved.

Log font size: Appearance & highlighting, 10–24 logical pixels. Apply and save
updates all panes; Cancel discards the edit.

Workspace: %APPDATA%/DingoTail.WinForms/workspace.json.
Code is GPL-3.0-only. See LICENSE, COPYRIGHT, BRANDING.md and licenses/.
Material Icons use their separately bundled license.
RDP, additional DPI settings and a clean machine without .NET were not tested.
